import Head from 'next/head'

export default function Home() {
  return (
    <>
      <Head>
        <title>E-Mongolia Style PWA</title>
        <meta name="description" content="Progressive Web App like E-Mongolia v4" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#2f7df7" />
      </Head>
      <main style={{ maxWidth: '480px', margin: 'auto', padding: '16px', fontFamily: 'Arial, sans-serif' }}>
        <h1 style={{ color: '#2f7df7', textAlign: 'center' }}>E-Mongolia Style PWA</h1>
        <p style={{ textAlign: 'center' }}>Welcome to the E-Mongolia style Progressive Web App.</p>
        <section style={{ marginTop: '24px' }}>
          <h2 style={{ color: '#2f7df7' }}>Services</h2>
          <ul>
            <li>Online application for government services</li>
            <li>Document verification</li>
            <li>Appointment scheduling</li>
            <li>Real-time notifications</li>
          </ul>
        </section>
      </main>
    </>
  )
}